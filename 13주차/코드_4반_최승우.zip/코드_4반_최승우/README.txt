코드_4반_최승우 — 데이터분석 미니프로젝트
Target_1(D+3 KOSPI 상승) · Target_2(D+3 건강식품 지수 상승) 확률 예측, 평가지표 AUC
최종 모델: T1 = E13_t1_blend (RF + 로지스틱 50:50), T2 = E10_t2_sh1_anom (LR + RF + XGB 평균)

[폴더 구성]
  1_notebooks/   실행할 노트북 (모두 이 폴더에서 실행 → 상대경로 ../2_data 등 사용)
     train.ipynb                  ★ Private 재현: 피처 생성 → 실험 E0~E13 → 최종 선택 → 제출 파일
     01_EDA_피처인사이트.ipynb     변수군 × Target 관계, 파생변수 근거 (보고서 그림 1~3)
     02_Prophet_시계열분석.ipynb   요일·추세 분해 (보고서 그림 4, prophet 패키지 필요)
     03_T1_분기점검증.ipynb        T1 판단 통계 검정 · Public 해석 · 전환 모델 (보고서 그림 10~19)
                                   ※ train.ipynb §1~§4를 불러와 사용
     Mini-Project_Baseline.ipynb  제공 Baseline (경로만 수정)
  2_data/        제공 데이터 (train · test_public · test_private · sample_submission · 변수 설명서)
  3_outputs/     private_4반_최승우.csv (제출본) · experiments.csv (실험 기록 겸 캐시)
  4_figures/     보고서 그림 20개 (그림 번호순 파일명) · 최종_실험비교.png (train.ipynb §5-2 출력)

[Private 재현]  1_notebooks/train.ipynb 를 Python 3.11 커널(scikit-learn 1.9, xgboost, pandas)로 Run All
  - §1  MODE = 'private' (설정된 상태로 저장됨)
  - §4  실험은 3_outputs/experiments.csv 캐시로 건너뜀(설정이 같을 때). 처음부터 재학습하려면 §1 FORCE = True
  - §5  평균−표준편차 기준 자동 선택 → T1 = E13_t1_blend, T2 = E10_t2_sh1_anom → Train 924일 전체로 재학습
  - §6  3_outputs/private_4반_최승우.csv 생성 + 형식 검증
        (같은 이름 파일이 있으면 덮어쓰지 않고 중단: OVERWRITE=False → 재현하려면 기존 파일을 옮기거나 OVERWRITE=True)
        재생성 결과는 제출본과 최대 4e-16 차이(부동소수점 계산 순서), 예측 순위 동일 → AUC 동일

[Leakage 방지]  파생변수는 과거·당일 값만 사용, Test의 Target 미사용, 결측 대체·표준화는 fold 학습 구간으로만 학습
